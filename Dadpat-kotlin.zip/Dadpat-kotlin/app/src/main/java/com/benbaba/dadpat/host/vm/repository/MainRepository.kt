package com.benbaba.dadpat.host.vm.repository

import com.benbaba.dadpat.host.R
import com.benbaba.dadpat.host.config.Constants
import com.benbaba.dadpat.host.http.action
import com.benbaba.dadpat.host.model.PluginBean
import com.benbaba.dadpat.host.ui.MainActivity
import com.bhx.common.utils.LogUtils
import com.bhx.common.utils.Md5Utils
import com.qihoo360.replugin.RePlugin
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers
import zlc.season.rxdownload3.RxDownload
import zlc.season.rxdownload3.RxDownloadI
import zlc.season.rxdownload3.core.*
import java.io.File
import java.util.*


/**
 * 主页面的Repository(仓库)类
 */
class MainRepository : BaseEventRepository() {
    private val missionMap = hashMapOf<PluginBean, Mission>()

    /**
     * 获取插件列表
     */
    fun getPluginList() {
        addDisposable(
            apiService.getPluginList()
                .action {
                    handlePluginList(it)
                    sortPluginList(it)
                    //将数据发送到MainActivity
                    sendData(Constants.EVENT_KEY_MAIN, Constants.TAG_GET_PLUGIN_LIST, it)
                }
        )
    }

    /**
     * 与本地版本对比设置插件的状态
     */
    private fun handlePluginList(list: List<PluginBean>) {
        //首先判断是否安
        list.forEach {
            it.savePath = Constants.PLUGIN_SAVE_DIR
            if (it.isRelease == "1") {
                val isInstall = RePlugin.isPluginInstalled(it.pluginName)
                it.isInstall = isInstall
                if (isInstall) {
                    val version = RePlugin.getPluginVersion(it.pluginName)
                    it.isNeedUpdate = it.version > version
                }
            }
        }

    }

    /**
     * 排序插件的List
     */
    private fun sortPluginList(list: List<PluginBean>) {
        //按照是否发布排序
        Collections.sort(list) { o1, o2 ->
            val isReleaseO1 = Integer.valueOf(o1.isRelease)
            val isReleaseO2 = Integer.valueOf(o2.isRelease)
            isReleaseO1 - isReleaseO2
        }
        // 按照安装顺序排序
        Collections.sort(list) { o1, o2 ->
            val isInstallO1 = o1.isInstall
            val isInstallO2 = o2.isInstall
            var sorts = 0
            if (isInstallO1 && !isInstallO2) {
                sorts = -1
            } else if (!isInstallO1 && isInstallO2) {
                sorts = 1
            }
            sorts
        }
        var index = 0
        //设置插件的图片
        list.forEach {
            if (it.isRelease == "1") {
                it.imgRes = Constants.RES_IMG_MAP[it.pluginName]!!
            } else {
                when (index) {
                    0 -> it.imgRes = R.drawable.main_item_bitmap_01
                    1 -> it.imgRes = R.drawable.main_item_bitmap_02
                    2 -> it.imgRes = R.drawable.main_item_bitmap_03
                    3 -> it.imgRes = R.drawable.main_item_bitmap_04
                }
                index++
            }
        }

    }

    /**
     * 下载对应的插件 如果已经创建任务的话判断是否正在下载执行相反的逻辑
     */
    fun downlandPlugin(bean: PluginBean) {
        if (missionMap.contains(bean)) {
            // 创建过下载任务
            if (bean.isDownLanding) {
                missionMap[bean]?.let { stopDownland(it) }
            } else {
                missionMap[bean]?.let { startDownland(it) }
            }
            return
        }
        LogUtils.i("需要下载的插件$bean")
        val mission = Mission(bean.url, bean.pluginName + ".apk", bean.savePath, true)
        if (!missionMap.contains(bean)) {
            missionMap[bean] = mission
        }
        addDisposable(RxDownload.create(mission, true)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe {
                //发送下载进度
                handleStatus(it, bean)
                val percent = String.format("%.2f", it.downloadSize.toFloat() / it.totalSize.toFloat())   //1.13
                bean.downProgress = percent.toFloat()
                LogUtils.i("下载进度status:$percent")
                sendData(Constants.EVENT_KEY_MAIN, Constants.TAG_PLUGIN_DOWN_PROGRESS, bean)
            })

    }

    /**
     * 处理下载状态
     */
    private fun handleStatus(status: Status, bean: PluginBean) {
        when (status) {
            is Normal -> {
                bean.isDownLanding = true
            }
            is Failed -> {
                bean.isDownLanding = false
                //下载失败
                missionMap.remove(bean)
                sendData(Constants.EVENT_KEY_MAIN, "", bean)
            }
            is Succeed -> {
                LogUtils.i("下载成功")
                bean.isDownLanding = false
                //下载成功
                missionMap.remove(bean)
                installPlugin(bean)
            }
        }
    }

    /**
     * 安装插件
     */
    private fun installPlugin(bean: PluginBean) {
        addDisposable(
            Single.create<PluginBean> {
                val path = bean.savePath + "/" + bean.pluginName + ".apk"
                val apkMd5 = Md5Utils.getFileMD5(File(path))
                if (bean.apkMd5 != apkMd5) {
                    it.onError(Throwable("下载文件和本地的MD5不相同"))
                }
                val info = RePlugin.install(path)
                if (info != null) {
                    it.onSuccess(bean)
                }
            }.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    LogUtils.i("安装完成")
                    sendData(Constants.EVENT_KEY_MAIN, Constants.TAG_PLUGIN_INSTALL_SUCCESS, it)
                }, {
                    LogUtils.i("安装失败")
                })
        )
    }

    /**
     * 切换下载或者暂停下载
     */
    fun togglePlginBean(bean: PluginBean) {
        if (!missionMap.containsKey(bean)) {
            return
        }
        if (bean.isDownLanding) {
            stopDownland(missionMap[bean]!!)
        } else {
            startDownland(missionMap[bean]!!)
        }
    }

    fun startDownland(mission: Mission) {
        addDisposable(RxDownload.start(mission).subscribe())
    }

    fun stopDownland(mission: Mission) {
        addDisposable(RxDownload.stop(mission).subscribe())
    }

    fun startAllDownland() {
        addDisposable(RxDownload.startAll().subscribe())
    }

    fun stopAllDownland() {
        addDisposable(RxDownload.stopAll().subscribe())
    }

    /**
     *
     */
    fun startPluginActivity(bean: PluginBean) {
        //当插件对象不为空的时候
        if (!bean.isInstall || bean.isNeedUpdate || bean.isRelease.equals("2")) {
            return
        }
        addDisposable(Single.create<Boolean> {
            val info = RePlugin.getPluginInfo(bean.pluginName)
            if (info != null) {
                val result = RePlugin.preload(info)
                it.onSuccess(result)
            } else {
                it.onSuccess(false)
            }
        }.subscribeOn(Schedulers.io())
            .doOnSubscribe {
                val loadingGifName = when (bean.pluginName) {
                    "Plugin_Web_Calendar" -> "gif/loading_calendar.gif"
                    "Plugin_Web_Astronomy" -> "gif/loading_astronomy.gif"
                    "Plugin_Web_ChinaHistory" -> "gif/loading_china_history.gif"
                    "Plugin_Web_Earth" -> "gif/loading_earth.gif"
                    "Plugin_Web_Animal" -> "gif/loading_animal.gif"
                    "Plugin_Web_English" -> "gif/loading_abc.gif"
                    "Plugin_Web_Picture" -> "gif/loading_picture.gif"
                    "Plugin_Web_WorldHistory" -> "gif/loading_world_history.gif"
                    else -> "gif/main_loading.gif"
                }
                sendData(Constants.EVENT_KEY_MAIN,Constants.TAG_START_PLUGIN_ACTIVITY_DIALOG, loadingGifName)
            }
            .subscribeOn(AndroidSchedulers.mainThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(Consumer {
                if (it) {
                    sendData(Constants.EVENT_KEY_MAIN,Constants.TAG_PRELOAD_PLUGIN_SUCCESS, bean)
                }
            })
        )


    }
}