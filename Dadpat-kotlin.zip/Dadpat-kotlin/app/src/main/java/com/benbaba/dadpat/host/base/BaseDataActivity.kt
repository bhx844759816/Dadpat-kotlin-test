package com.benbaba.dadpat.host.base

import android.os.Bundle
import androidx.lifecycle.Observer
import com.benbaba.dadpat.host.config.Constants
import com.benbaba.dadpat.host.view.dialog.LoadingDialogFragment
import com.bhx.common.http.ApiException
import com.bhx.common.mvvm.BaseMVVMActivity
import com.bhx.common.mvvm.BaseViewModel
import com.bhx.common.utils.AppManager
import com.bhx.common.utils.LogUtils
import com.bhx.common.utils.ToastUtils

abstract class BaseDataActivity<T : BaseViewModel<*>?> : BaseMVVMActivity<T>() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppManager.getAppManager().addActivity(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        AppManager.getAppManager().removeActivity(this)
    }

    override fun onResume() {
        super.onResume()
        //注册加载对话框监听
        registerObserver(Constants.EVENT_KEY_LOADING_DIALOG, Constants.TAG_LOADING_DIALOG, Boolean::class.java).observe(
            this, Observer {
                if (it != null && it) {
                    LoadingDialogFragment.show(this)
                } else {
                    LoadingDialogFragment.dismiss(this)
                }
            })
        // 注册Http请求得监听
        registerObserver(
            Constants.EVENT_KEY_HTTP_REQUEST_ERROR,
            Constants.TAG_HTTP_REQUEST_ERROR,
            Throwable::class.java
        ).observe(
            this, Observer {
                if (it is ApiException) {
                    val code = it.code
                    ToastUtils.toastShort(it.message)
                }
            }
        )
    }

    override fun onPause() {
        super.onPause()
        //页面不显示的时候取消注册对话框监听
        unRegisterObserver(Constants.EVENT_KEY_LOADING_DIALOG, Constants.TAG_LOADING_DIALOG)
        unRegisterObserver(Constants.EVENT_KEY_HTTP_REQUEST_ERROR, Constants.TAG_HTTP_REQUEST_ERROR)
    }
}