package com.benbaba.dadpat.host.vm

import android.app.Application
import android.content.Context
import com.benbaba.dadpat.host.App
import com.benbaba.dadpat.host.R
import com.benbaba.dadpat.host.config.Constants
import com.benbaba.dadpat.host.model.PluginBean
import com.benbaba.dadpat.host.view.dialog.LoadingDialogFragment
import com.benbaba.dadpat.host.vm.repository.MainRepository
import com.bhx.common.mvvm.BaseViewModel
import com.bhx.common.utils.FileUtils
import com.qihoo360.replugin.RePlugin
import java.io.File
import java.util.*

class MainViewModel(application: Application) : BaseViewModel<MainRepository>(application) {
    /**
     * 保存数据List
     *
     *
     *
     */


    /**
     * 获取插件列表
     */
    fun getPluginList() {
        mRepository.getPluginList()
    }

    /**
     * 下载插件
     */
    fun downLandPlugin(bean: PluginBean) {
        mRepository.downlandPlugin(bean)
    }

    fun stopDownlandPlugin(bean: PluginBean) {

    }

    fun isPluginInstalling(bean: PluginBean) {

    }

    public fun handlePluginList(list: List<PluginBean>) {
        var index = 0
        list.forEach {
            it.savePath = Constants.PLUGIN_SAVE_DIR
            if (it.isRelease == "1") {
                it.imgRes = Constants.RES_IMG_MAP[it.pluginName]!!
                val isInstall = RePlugin.isPluginInstalled(it.pluginName)
                it.isInstall = isInstall
                if (isInstall) {
                    val version = RePlugin.getPluginVersion(it.pluginName)
                    it.isNeedUpdate = it.version > version
                }
            } else {
                when (index) {
                    0 -> it.imgRes = R.drawable.main_item_bitmap_01
                    1 -> it.imgRes = R.drawable.main_item_bitmap_02
                    2 -> it.imgRes = R.drawable.main_item_bitmap_03
                    3 -> it.imgRes = R.drawable.main_item_bitmap_04
                }
                index++
            }
        }

    }

    public fun sortedPluginList(list: List<PluginBean>) {
        //按照是否发布排序
        Collections.sort(list) { o1, o2 ->
            val isReleaseO1 = Integer.valueOf(o1.isRelease)
            val isReleaseO2 = Integer.valueOf(o2.isRelease)
            isReleaseO1 - isReleaseO2
        }
        // 按照安装顺序排序
        Collections.sort(list) { o1, o2 ->
            val isInstallO1 = o1.isInstall
            val isInstallO2 = o2.isInstall
            var sorts = 0
            if (isInstallO1 && !isInstallO2) {
                sorts = -1
            } else if (!isInstallO1 && isInstallO2) {
                sorts = 1
            }
            sorts
        }
    }

    /**
     * 删除插件
     */
    fun deletePlugin(mDragPluginBean: PluginBean?) {
        if (mDragPluginBean != null) {
            val file = getApplication<App>().applicationContext.getExternalFilesDir(
                "benbaba" + File.separator + mDragPluginBean.pluginName
            )
            //删除缓存
            FileUtils.deleteDirFiles(file)
            //删除插件
            RePlugin.uninstall(mDragPluginBean.pluginName)
        }
    }

    /**
     * 跳转到对应的插件界面
     */
    fun startPluginActivity(bean: PluginBean?) {
        bean?.let {
            mRepository.startPluginActivity(it)


        }
    }
}