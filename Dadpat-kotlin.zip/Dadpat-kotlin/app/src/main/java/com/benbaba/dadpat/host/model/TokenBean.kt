package com.benbaba.dadpat.host.model

/**
 * Created by Administrator on 2019/5/15.
 */
data class TokenBean(val token: String, val user: User)