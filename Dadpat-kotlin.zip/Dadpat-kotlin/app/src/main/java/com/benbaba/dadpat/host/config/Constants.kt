package com.benbaba.dadpat.host.config

import android.os.Environment
import com.benbaba.dadpat.host.R
import java.io.File
import java.util.HashMap

class Constants {
    companion object {
        var BASE_URL = "http://www.dadpat.com/"
        const val EVENT_KEY_LOADING = "EVENT_KEY_LOADING" //loading页面
        const val TAG_LOADING = "tag_loading" //
        //对话框的
        const val EVENT_KEY_LOADING_DIALOG = "event_key_loading_dialog"
        const val TAG_LOADING_DIALOG = "tag_loading_dialog"
        //http请求报错
        const val EVENT_KEY_HTTP_REQUEST_ERROR = "event_key_http_request_error"
        const val TAG_HTTP_REQUEST_ERROR = "tag_http_request_error"


        //手机号登陆
        const val EVENT_KEY_PHONE_LOGIN = "event_key_phone_login"
        const val TAG_LOGIN_RESULT = "tag_login_result"
        //注册
        const val EVENT_KEY_REGISTER = "event_key_register"
        const val TAG_REGISTER_CODE = "tag_register_code"
        const val TAG_REGISTER_RESULT = "tag_register_result"
        //忘记密码
        const val EVENT_KEY_FORGET_PASSWORD = "event_key_forget_password"
        const val TAG_MODIFY_PASSWORD_RESULT = "tag_modify_password_result" //修改密码的结果
        //主页面
        const val EVENT_KEY_MAIN = "event_key_main"// MainActivity的事件
        const val TAG_GET_PLUGIN_LIST = "tag_get_plugin_list"//获取插件的列表事件
        const val TAG_PLUGIN_DOWN_ERROR = "tag_plugin_down_error"//插件安装失败的事件
        const val TAG_PLUGIN_INSTALL_SUCCESS = "tag_plugin_install_success"//插件安装成功的事件
        const val TAG_PLUGIN_DOWN_PROGRESS = "tag_plugin_down_progress"//下载插件的进度事件
        const val TAG_CONFIRM_DELETE_PLUGIN = "tag_confirm_delete_plugin"//确认删除插件的事件
        const val TAG_START_PLUGIN_ACTIVITY_DIALOG = "tag_start_plugin_activity_dialog"//弹出加载插件的对话框事件
        const val TAG_PRELOAD_PLUGIN_SUCCESS = "tag_preload_plugin_success"//预加载插件成功的事件
        const val TAG_CHANGE_USER_HEAD_PHOTO = "tag_change_user_head_photo"//点击改换头像的事件
        const val TAG_SAVE_USER_INFO = "tag_save_user_info" //保存用户信息的事件
        const val TAG_CHECK_APP_VERSION = "tag_check_app_version" //检查App的版本
        const val TAG_LOGIN_OUT = "tag_login_out" //退出登陆

        //
        const val SP_FILENAME = "FILE_NAME"
        const val SP_LOGIN = "login"
        const val SP_TOKEN = "token"
        const val SP_LOGIN_TYPE = "login_type"
        val RES_IMG_MAP: HashMap<String, Int> = object : HashMap<String, Int>() {
            init {
                put("Plugin_Web_Calendar", R.drawable.main_item_calendar)
                put("Plugin_Web_Astronomy", R.drawable.main_item_astronomy)
                put("Plugin_Web_ChinaHistory", R.drawable.main_item_chinese_history)
                put("Plugin_Web_Earth", R.drawable.main_item_earth)
                put("Plugin_Web_Animal", R.drawable.main_item_animal)
                put("Plugin_Web_English", R.drawable.main_item_abc)
                put("Plugin_Web_Picture", R.drawable.main_item_picture)
                put("Plugin_Web_WorldHistory", R.drawable.main_item_world_history)
                put("Plugin_Dadpat", R.drawable.main_item_dadpat)
                put("Plugin_Rhythm", R.drawable.main_item_rhythm)
                put("Plugin_DadpatGuess", R.drawable.main_item_guess)
                put("Plugin_Piano", R.drawable.main_item_piano)
            }
        }
        val RES_TEXT_MAP: HashMap<String, Int> = object : HashMap<String, Int>() {
            init {
                put("Plugin_Web_Calendar", R.drawable.main_item_calendar_text)
                put("Plugin_Web_Astronomy", R.drawable.main_item_astronomy_text)
                put("Plugin_Web_ChinaHistory", R.drawable.main_item_chinese_history_text)
                put("Plugin_Web_Earth", R.drawable.main_item_earth_text)
                put("Plugin_Web_Animal", R.drawable.main_item_animal_text)
                put("Plugin_Web_English", R.drawable.main_item_abc_text)
                put("Plugin_Web_Picture", R.drawable.main_item_picture_text)
                put("Plugin_Web_WorldHistory", R.drawable.main_item_world_history_text)
                put("Plugin_Dadpat", R.drawable.main_item_dadpat_text)
                put("Plugin_Rhythm", R.drawable.main_item_rhythm_text)
                put("Plugin_DadpatGuess", R.drawable.main_item_guess_text)
                put("Plugin_Piano", R.drawable.main_item_piano_text)
            }
            //

        }
        val PLUGIN_SAVE_DIR = (Environment.getExternalStorageDirectory().toString() + File.separator + "benbaba"
                + File.separator + "plugins" + File.separator)


    }
}