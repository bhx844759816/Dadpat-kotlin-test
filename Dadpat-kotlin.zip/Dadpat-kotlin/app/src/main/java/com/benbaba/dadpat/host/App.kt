package com.benbaba.dadpat.host

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.res.Configuration
import androidx.multidex.MultiDex
import com.benbaba.dadpat.host.config.Constants
import com.benbaba.dadpat.host.http.TokenInterceptor
import com.benbaba.dadpat.host.utils.SPUtils
import com.bhx.common.BaseApplication
import com.bhx.common.http.RetrofitManager
import com.mob.MobSDK
import com.qihoo360.replugin.RePlugin
import zlc.season.rxdownload3.core.DownloadConfig

open class App : BaseApplication() {
    private var token: String? = null
    override fun onCreate() {
        super.onCreate()
        //Replugin的初始化
        RePlugin.App.onCreate()
        instance = this
        //初始化MobSdk
        MobSDK.init(this)
        //RetrofitManager的初始化
        val builder = RetrofitManager.Builder()
            .setBaseUrl(Constants.BASE_URL)
            .setInterceptorList(listOf(TokenInterceptor()))
        RetrofitManager.getInstance().init(builder)
        //RxDownland的配置
        val rxDownlandBuilder = DownloadConfig.Builder.create(this)
            .enableAutoStart(true)              //自动开始下载
            .setMaxRange(10)       // 每个任务并发的线程数量
            .setMaxMission(5)      // 同时下载的任务数量
        DownloadConfig.init(rxDownlandBuilder)
        //
        token = SPUtils.get(this, Constants.SP_TOKEN, "") as String

    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        RePlugin.App.attachBaseContext(this)
        MultiDex.install(this)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        RePlugin.App.onLowMemory()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        RePlugin.App.onTrimMemory(level)
    }

    override fun onConfigurationChanged(newConfig: Configuration?) {
        super.onConfigurationChanged(newConfig)
        RePlugin.App.onConfigurationChanged(newConfig)
    }

    /**
     * 设置Token
     */
    fun setToken(token: String) {
        this.token = token
        SPUtils.put(this, Constants.SP_TOKEN, token)
    }

    /**
     * 获取token
     */
    fun getToken() = token

    companion object {
        @SuppressLint("StaticFieldLeak")
        private var instance: App? = null

        fun instance() = instance!!
    }

}