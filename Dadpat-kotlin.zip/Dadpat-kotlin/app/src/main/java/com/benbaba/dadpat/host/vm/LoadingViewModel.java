package com.benbaba.dadpat.host.vm;

import android.app.Application;
import androidx.annotation.NonNull;
import com.benbaba.dadpat.host.vm.repository.LoadingRepository;
import com.bhx.common.mvvm.BaseViewModel;
import com.bhx.common.utils.ToastUtils;

/**
 *
 */
public class LoadingViewModel extends BaseViewModel<LoadingRepository> {

    public LoadingViewModel(@NonNull Application application) {
        super(application);
    }

    public void getUserInfo() {
        ToastUtils.toastShort("获取用户信息");
    }
}
