package com.benbaba.dadpat.host.vm.repository

import android.annotation.SuppressLint
import com.benbaba.dadpat.host.App
import com.benbaba.dadpat.host.config.Constants
import com.benbaba.dadpat.host.http.action
import com.benbaba.dadpat.host.http.handleResult
import com.benbaba.dadpat.host.utils.applySchedulers
import com.bhx.common.utils.LogUtils
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Consumer

/**
 * 手机号登陆的请求类
 */
class PhoneLoginRepository : BaseEventRepository() {

    @SuppressLint("CheckResult")
    fun login(phone: String, psd: String) {
        val params = hashMapOf("userMobile" to phone, "userPwd" to psd)
        addDisposable(apiService.doLogin(params).action {
            LogUtils.i("login success:$it")
            sendData(Constants.EVENT_KEY_PHONE_LOGIN, Constants.TAG_LOGIN_RESULT, it)
        })
    }

}