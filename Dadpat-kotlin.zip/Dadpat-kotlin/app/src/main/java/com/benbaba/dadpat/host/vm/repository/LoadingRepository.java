package com.benbaba.dadpat.host.vm.repository;

import com.bhx.common.mvvm.BaseRepository;

public class LoadingRepository extends BaseRepository {
}
