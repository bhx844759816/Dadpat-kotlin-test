package com.benbaba.dadpat.host.view.dialog

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Build
import android.text.TextUtils
import android.view.View
import android.widget.DatePicker
import androidx.fragment.app.FragmentActivity
import com.benbaba.dadpat.host.R
import com.benbaba.dadpat.host.config.Constants
import com.benbaba.dadpat.host.model.User
import com.benbaba.dadpat.host.utils.MatisseUtils
import com.benbaba.dadpat.host.utils.clickWithTrigger
import com.bhx.common.base.BaseDialogFragment
import com.bhx.common.event.LiveBus
import com.bhx.common.glide.ImageLoader
import com.bhx.common.utils.AppCacheUtils
import com.bhx.common.utils.ToastUtils
import com.qihoo360.loader2.PMF.getApplicationContext
import com.tbruyelle.rxpermissions2.RxPermissions
import com.trello.rxlifecycle2.android.ActivityEvent
import com.zhihu.matisse.Matisse
import com.zhihu.matisse.compress.CompressHelper
import com.zhihu.matisse.compress.FileUtil
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.dialog_person_message.*
import java.io.File
import java.util.*

/**
 * 个人信息
 */
class PersonInfoDialogFragment : BaseDialogFragment() {
    private var mDataPickerDialog: DatePickerDialog? = null
    private var mUser: User? = null
    private val takePhotoCode = 0x02
    private var mPhotoFile: File? = null

    private val mDateListener = (DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
        val time = year.toString() + "-" + (month + 1) + "-" + dayOfMonth
        personBirthday.setText(time)
    })

    override fun getLayoutId(): Int = R.layout.dialog_person_message


    override fun initView(view: View?) {
        super.initView(view)
        //点击保存
        save.clickWithTrigger {
            val userName = personName.text.toString().trim()
            if (TextUtils.isEmpty(userName)) {
                ToastUtils.toastShort("用户名不能为空")
                return@clickWithTrigger
            }
            val userBirthday = personBirthday.text.toString().trim()
            if (TextUtils.isEmpty(userBirthday)) {
                ToastUtils.toastShort("生日不能为空")
                return@clickWithTrigger
            }
            LiveBus.getDefault().postEvent(Constants.EVENT_KEY_MAIN, Constants.TAG_SAVE_USER_INFO, true)
        }
        //点击出生日期
        personBirthday.clickWithTrigger {
            showDataPicker()
        }
        //点击头像
        personHead.clickWithTrigger {

            //            LiveBus.getDefault().postEvent(Constants.EVENT_KEY_MAIN, Constants.TAG_CHANGE_USER_HEAD_PHOTO, true)
        }
        //用户反馈
        personFeedback.clickWithTrigger {
            activity?.let {
                FeedBackDialogFragment.show(it, mUser)
            }
        }
        //检查版本
        checkAppVersion.clickWithTrigger {
            LiveBus.getDefault().postEvent(Constants.EVENT_KEY_MAIN, Constants.TAG_CHECK_APP_VERSION, true)

        }
        //版权信息
        copyright.clickWithTrigger {

        }
        //用户协议
        userProtocol.clickWithTrigger {
            activity?.let {
                UserProtocolDialogFragment.show(it)
            }
        }
        //清理缓存
        clearCache.clickWithTrigger {
            AppCacheUtils.clearAllCache(context)
            totalCache.text = AppCacheUtils.getTotalCacheSize(context)
        }
        //注销登陆
        loginOff.clickWithTrigger {
            LiveBus.getDefault().postEvent(Constants.EVENT_KEY_MAIN, Constants.TAG_LOGIN_OUT, true)
        }
    }

    /**
     * 跳转到选择头像的界面
     */
    private fun takePhoto() {
        activity?.let {
            RxPermissions(it).requestEach(Manifest.permission.CAMERA)
                .subscribe { permission ->
                    if (permission.granted) {
                        MatisseUtils.openPhoto(it, takePhotoCode, 1)
                    } else if (!permission.shouldShowRequestPermissionRationale) {
                        //展示权限被拒绝的情况
                    }
                }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == takePhotoCode) {
            //接收到选择的照片
            val file = FileUtil.getFileByPath(Matisse.obtainPathResult(data).get(0))
            // 压缩后的文件（多个文件压缩可以循环压缩）
            mPhotoFile = CompressHelper.getDefault(getApplicationContext()).compressToFile(file)
            //显示到头像上
            ImageLoader.displayImage(context, mPhotoFile, mainHeadImg)
        }
    }

    private fun showDataPicker() {
        if (mDataPickerDialog == null) {
            val ca = Calendar.getInstance()
            val year = ca.get(Calendar.YEAR)
            val month = ca.get(Calendar.MONTH)
            val day = ca.get(Calendar.DAY_OF_MONTH)
            mDataPickerDialog = DatePickerDialog(context, mDateListener, year, month, day)
        }
        mDataPickerDialog?.show()

    }

    companion object {
        private val TAG = PersonInfoDialogFragment::class.simpleName


        fun show(activity: FragmentActivity) {
            var fragment = activity.supportFragmentManager.findFragmentByTag(TAG)
            if (fragment == null) {
                fragment = PersonInfoDialogFragment()
            }
            if (!fragment.isAdded) {
                val manager = activity.supportFragmentManager
                val transaction = manager.beginTransaction()
                transaction.add(fragment, TAG)
                transaction.commitAllowingStateLoss()
            }
        }

        fun dismiss(activity: FragmentActivity) {
            val fragment = activity.supportFragmentManager?.findFragmentByTag(TAG)
            if (fragment != null && fragment is PersonInfoDialogFragment && fragment.isAdded) {
                fragment.dismissAllowingStateLoss()
            }
        }
    }
}