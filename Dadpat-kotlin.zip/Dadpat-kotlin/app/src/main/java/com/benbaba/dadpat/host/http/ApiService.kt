package com.benbaba.dadpat.host.http

import com.benbaba.dadpat.host.model.HttpResult
import com.benbaba.dadpat.host.model.PluginBean
import com.benbaba.dadpat.host.model.TokenBean
import com.benbaba.dadpat.host.model.User
import io.reactivex.Observable
import retrofit2.http.*
import java.util.*

/**
 * Api请求的接口类
 */
interface ApiService {
    //注册
    @FormUrlEncoded
    @POST("user/auth/register.do")
    fun register(@FieldMap map: Map<String, String>): Observable<HttpResult<User>>

    //验证验证码
    @FormUrlEncoded
    @POST("user/sms/verify.do")
    fun verifySms(@FieldMap map: Map<String, String>): Observable<HttpResult<Any>>

    //jwt方式登陆
    @FormUrlEncoded
    @POST("user/jwt/access.do")
    fun doLogin(@FieldMap map: Map<String, String>): Observable<HttpResult<TokenBean>>

    // 修改密码
    @FormUrlEncoded
    @POST("user/auth/updateCredentialBySms.do")
    fun modifyPsd(@FieldMap params: Map<String, String>): Observable<HttpResult<String>>

    //获取插件列表
    @GET("apkType/getLastApkByOrder.do?order=2")
    fun getPluginList(): Observable<HttpResult<List<PluginBean>>>

    //反馈意见
    @FormUrlEncoded
    @POST("advise/save.do")
    @Headers("Content-Type:application/x-www-form-urlencoded; charset=utf-8")
    fun postFeedBack(@FieldMap map: Map<String, String>): Observable<HttpResult<String>>

}