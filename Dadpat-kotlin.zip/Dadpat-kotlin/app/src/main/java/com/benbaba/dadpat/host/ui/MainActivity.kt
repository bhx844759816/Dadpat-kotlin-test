package com.benbaba.dadpat.host.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.text.TextUtils
import android.view.View
import android.view.animation.Animation
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.benbaba.dadpat.host.R
import com.benbaba.dadpat.host.adapter.MainAdapter
import com.benbaba.dadpat.host.config.Constants
import com.benbaba.dadpat.host.model.PluginBean
import com.benbaba.dadpat.host.model.User
import com.benbaba.dadpat.host.utils.*
import com.benbaba.dadpat.host.view.NoScrollLayoutManager
import com.benbaba.dadpat.host.view.dialog.ConfirmDeleteDialogFragment
import com.benbaba.dadpat.host.view.dialog.LoadingDialogFragment
import com.benbaba.dadpat.host.view.dialog.PersonInfoDialogFragment
import com.benbaba.dadpat.host.view.dialog.ReStartAPPDialogFragment
import com.benbaba.dadpat.host.vm.MainViewModel
import com.bhx.common.glide.ImageLoader
import com.bhx.common.mvvm.BaseMVVMActivity
import com.bhx.common.utils.LogUtils
import com.bhx.common.utils.NetworkUtils
import com.qihoo360.replugin.RePlugin
import kotlinx.android.synthetic.main.activity_main.*

/**
 * 主页面
 */
class MainActivity : BaseMVVMActivity<MainViewModel>() {
    //用户信息
    private lateinit var mUser: User
    //插件集合对象
    private var mPluginList: MutableList<PluginBean> = ArrayList()
    private var isAllowNetWorkDownLanding = false
    private var mDragPluginBean: PluginBean? = null
    private var mDragView: View? = null
    //首页列表适配器
    private lateinit var mMainAdapter: MainAdapter
    private lateinit var mDragHelper: ItemTouchHelper
    private var isDialogShow = false

    private val dragItemCallBack: DragItemCallBack by lazy {
        DragItemCallBack(mMainAdapter, mPluginList, mainTrash)
    }
    //拖拽排序的CallBack
    private val mItemDragListener = object : DragItemCallBack.OnItemDragListener {
        override fun startDrag() {
            isDialogShow = false
            setTrashVisible()
        }

        override fun deleteItem(view: View?, position: Int) {
            isDialogShow = true
            mDragView = view
            ConfirmDeleteDialogFragment.show(this@MainActivity, mPluginList[position].pluginAlias)
        }

        override fun clearView() {
            if (!isDialogShow) {
                setTrashInVisible()
            }
        }
    }
    // adapter数据改变的回调
    private val mAdapterDataObserver = object : RecyclerView.AdapterDataObserver() {
        override fun onChanged() {
            val list = mPluginList.subList(mPluginList.size - 4, mPluginList.size)
            mainShaderView.setShaderView(list)

        }

        override fun onItemRangeChanged(positionStart: Int, itemCount: Int) {
            val list = mPluginList.subList(mPluginList.size - 4, mPluginList.size)
            mainShaderView.setShaderView(list)
        }
    }

    /**
     * 获取布局ID
     */
    override fun getLayoutId(): Int {
        return R.layout.activity_main
    }

    /**
     * 设置事件的Key
     */
    override fun getEventKey(): Any {
        return Constants.EVENT_KEY_MAIN
    }

    /**
     * 初始化View
     */
    override fun initView() {
        super.initView()
        mUser = intent.getSerializableExtra("User") as User
        mMainAdapter = MainAdapter(this, mPluginList)
        mainRecyclerView.addItemDecoration(GridSpaceItemDecoration(this))
        mainRecyclerView.layoutManager = NoScrollLayoutManager(this, 4, GridLayoutManager.VERTICAL, false)
        mainRecyclerView.setHasFixedSize(true)
        mDragHelper = ItemTouchHelper(dragItemCallBack)
        mDragHelper.attachToRecyclerView(mainRecyclerView)
        mainRecyclerView.adapter = mMainAdapter
        initListener()
        initUser()
    }

    private fun initListener() {
        //注册触摸监听
        mainRecyclerView.addOnItemTouchListener(object : OnRecyclerItemClickListener(mainRecyclerView) {
            override fun onItemClick(vh: RecyclerView.ViewHolder?) {
                vh?.let {
                    val pos = it.adapterPosition
                    val bean = mPluginList[pos]
                    if (bean.isInstall && !bean.isNeedUpdate) {
                        mViewModel.startPluginActivity(bean)
                    } else {
                        //插件是否是开发完成
                        if (bean.isRelease == "2") {
                            return
                        }
                        //下载插件
                        if (NetworkUtils.isWifiConnected(this@MainActivity) || isAllowNetWorkDownLanding) {
                            mViewModel.downLandPlugin(bean)
                        } else {
                            //弹出是否在4G条件下下载
                        }
                    }
                }
            }

            override fun onItemLongClick(vh: RecyclerView.ViewHolder?) {
                vh?.let {
                    mDragPluginBean = mPluginList[vh.adapterPosition]
                    mDragPluginBean?.let {
                        if (it.isInstall) {
                            mDragHelper.startDrag(vh)
                        }
                    }
                }

            }
        })
        //注册数据改变的监听
        mMainAdapter.registerAdapterDataObserver(mAdapterDataObserver)
        //设置拖拽的监听
        dragItemCallBack.setOnItemDragListener(mItemDragListener)
        //点击头像的时候
        mainHeadImg.clickWithTrigger {
            PersonInfoDialogFragment.show(this@MainActivity)
        }

    }

    /**
     * 初始化用户信息
     */
    private fun initUser() {
        mUser.let {
            val url = if (!TextUtils.isEmpty(mUser.headImg) && mUser.headImg.startsWith("http")) {
                mUser.headImg
            } else {
                Constants.BASE_URL + "/" + mUser.headImg
            }
            //设置姓名
            mainName.text = mUser.userName
            //设置头像
            ImageLoader.displayImage(this, url, mainHeadImg)
        }
    }

    /**
     * 获取数据
     */
    override fun initData() {
        // 获取插件列表
        mViewModel.getPluginList()
    }

    /**
     * 事件订阅
     */
    override fun dataObserver() {
        //注册获取插件列表事件监听
        registerObserver(Constants.TAG_GET_PLUGIN_LIST, List::class.java).observe(this, Observer {
            if (it != null) {
                val list = it as List<PluginBean>
                mViewModel.handlePluginList(list)
                mViewModel.sortedPluginList(list)
                mPluginList.clear()
                mPluginList.addAll(list)
                mMainAdapter.notifyDataSetChanged()
            }
        })
        //注册下载进度事件监听
        registerObserver(Constants.TAG_PLUGIN_DOWN_PROGRESS, PluginBean::class.java).observe(this, Observer {
            val pos = mPluginList.indexOf(it)
            LogUtils.i("下载进度:$pos")
            mMainAdapter.notifyItemChanged(pos)
        })
        //注册安装事件监听
        registerObserver(Constants.TAG_PLUGIN_INSTALL_SUCCESS, PluginBean::class.java).observe(this, Observer {
            // 跳转到对应的插件Activity
            mViewModel.startPluginActivity(it)
        })
        //注册删除插件事件监听
        registerObserver(Constants.TAG_CONFIRM_DELETE_PLUGIN, Boolean::class.java).observe(this, Observer {
            // 跳转到对应的插件Activity
            if (it) {
                //删除插件
                mViewModel.deletePlugin(mDragPluginBean)
                mDragView?.visibility = View.VISIBLE
                mDragPluginBean?.isInstall = false
                mViewModel.sortedPluginList(mPluginList)
                mMainAdapter.notifyDataSetChanged()
                //开启动画
                val anim = ShakeViewAnim.tada(mainTrash)
                anim.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator?) {
                        super.onAnimationEnd(animation)
                        setTrashInVisible()
                    }
                })
                anim.start()
            } else {
                //取消删除插件
                setTrashInVisible()
                mDragView?.visibility = View.VISIBLE
            }
        })
        //跳转插件加载对话框事件
        registerObserver(Constants.TAG_START_PLUGIN_ACTIVITY_DIALOG, String::class.java).observe(this, Observer {
            LogUtils.i("显示打开插件的对话框")
            LoadingDialogFragment.show(this@MainActivity, it)
        })
        //预加载插件成功
        registerObserver(Constants.TAG_PRELOAD_PLUGIN_SUCCESS, PluginBean::class.java).observe(this, Observer {
            LogUtils.i("预加载插件成功")
            val intent = RePlugin.createIntent(it.pluginName, it.mainClass.trim())
            val isStartResult = RePlugin.startActivity(this@MainActivity, intent)
            if (!isStartResult) {
                LoadingDialogFragment.dismiss(this@MainActivity)
                ReStartAPPDialogFragment.show(this@MainActivity)
            }
        })
    }

    /**
     * 显示垃圾桶
     */
    private fun setTrashVisible() {
        mainTrash.visibility = View.VISIBLE
        mainTrash.animate()
            .translationX(0f)
            .setDuration(1000)
            .start()
    }

    override fun onResume() {
        super.onResume()
        LoadingDialogFragment.dismiss(this@MainActivity)
    }

    /**
     * 隐藏垃圾桶
     */
    private fun setTrashInVisible() {
        mainTrash.animate()
            .translationX(200f)
            .setDuration(1000)
            .start()
    }
}
