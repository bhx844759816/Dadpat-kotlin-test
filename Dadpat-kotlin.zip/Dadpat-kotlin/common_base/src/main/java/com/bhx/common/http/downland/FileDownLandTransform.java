package com.bhx.common.http.downland;

/**
 * 将下载文件得订阅者转换成 DownlandFileObservable
 */
public class FileDownLandTransform {

}
