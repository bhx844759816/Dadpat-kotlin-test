package com.bhx.common.http.upload;

/**
 * 文本参数
 */
public class StringParams {
    private String key;
    private String value;
}
