package com.bhx.common.http.upload;

public class Params {
}
