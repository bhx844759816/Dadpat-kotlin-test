package com.bhx.common.http.upload;

import java.io.File;

/**
 * 文件参数
 */
public class FileParams {
    private String key;
    private File file;

}
