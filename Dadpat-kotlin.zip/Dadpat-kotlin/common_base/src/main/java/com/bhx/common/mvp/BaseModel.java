package com.bhx.common.mvp;

/**
 * Model操作的基类
 */
public interface BaseModel {
}
